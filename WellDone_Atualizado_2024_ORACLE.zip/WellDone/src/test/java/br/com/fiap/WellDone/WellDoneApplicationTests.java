package br.com.fiap.WellDone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WellDoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
